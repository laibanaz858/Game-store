// Remove ALL game loading logic from script.js
// Keep only cart-related functions or other non-game-specific logic
// For example, if you have cart functions:

function addToCart(gameId) {
    // Your cart implementation
    console.log(`Added game ${gameId} to cart`);
    // Add actual cart logic here
}

// Keep other non-game-related functions if they exist