// Login Form
document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    const loginBtn = document.getElementById('login-btn');
    const loginError = document.getElementById('login-error');
    
    try {
        loginBtn.disabled = true;
        loginError.textContent = '';
        loginBtn.textContent = 'Logging in...';
        
        const response = await fetch(`http://localhost:3000/api/login`, {  // Changed to relative path
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });
        
        if (!response.ok) {
            const error = await response.json().catch(() => ({ message: 'Network response was not ok' }));
            throw new Error(error.message || 'Login failed. Please try again.');
        }
        
        const data = await response.json();
        localStorage.setItem('userId', data.userId);
        localStorage.setItem('username', data.username);
        
        window.location.href = 'home.html';
    } catch (err) {
        loginError.textContent = err.message.includes('Failed to fetch') 
            ? 'Cannot connect to server. Please check: 1) Server is running 2) Network connection'
            : err.message;
        console.error('Login error:', err);
    } finally {
        loginBtn.disabled = false;
        loginBtn.textContent = 'Login';
    }
});

// Registration Form
document.getElementById('register-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const registerBtn = document.getElementById('register-btn');
    const registerError = document.getElementById('register-error');
    
    try {
        registerBtn.disabled = true;
        registerError.textContent = '';
        registerBtn.textContent = 'Registering...';
        
        if (password.length < 6) {
            throw new Error('Password must be at least 6 characters');
        }
        
        const response = await fetch(`http://localhost:3000/api/register`, {  // Changed to relative path
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name, email, password })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || 'Registration failed. Please try again.');
        }
        
        alert('Registration successful! Please login.');
        document.getElementById('register-form').reset();
    } catch (err) {
        registerError.textContent = err.message.includes('Failed to fetch') 
            ? 'Cannot connect to server. Please check: 1) Server is running 2) Network connection'
            : err.message;
        console.error('Registration error:', err);
    } finally {
        registerBtn.disabled = false;
        registerBtn.textContent = 'Register';
    }
});