document.addEventListener('DOMContentLoaded', async () => {
    await loadCart();
    setupCheckout();
});

async function loadCart() {
    try {
        const userId = localStorage.getItem('userId');
        if (!userId) {
            window.location.href = 'login_registration.html';
            return;
        }

        const response = await fetch(`http://localhost:3000/api/cart?userId=${userId}`);
        if (!response.ok) throw new Error(await response.text());

        const cartItems = await response.json();
        displayCart(cartItems);
        updateTotal(cartItems);
    } catch (error) {
        console.error('Cart load error:', error);
        document.getElementById('cart-items').innerHTML = `
            <div class="error">Failed to load cart: ${error.message}</div>
        `;
    }
}

function displayCart(items) {
    const container = document.getElementById('cart-items');
    const emptyMessage = document.querySelector('.empty-cart-message');
    const cartSummary = document.getElementById('cartSummary');
    const itemCount = document.getElementById('itemCount');

    if (items.length === 0) {
        container.innerHTML = '<p>Your cart is empty</p>';
        emptyMessage.style.display = 'block';
        cartSummary.style.display = 'none';
        itemCount.textContent = '0 items';
        updateCartCountDisplay(0); // <- update nav count
        return;
    }

    container.innerHTML = items.map(item => `
        <div class="cart-item">
            <img src="${item.image_path || 'images/default-game.jpg'}" alt="${item.title}">
            <div class="item-details">
                <h3>${item.title}</h3>
                <p>$${item.price} × ${item.quantity}</p>
                <button onclick="removeFromCart(${item.game_id})">Remove</button>
            </div>
        </div>
    `).join('');

    emptyMessage.style.display = 'none';
    cartSummary.style.display = 'block';
    itemCount.textContent = `${items.length} items`;
    updateCartCountDisplay(items.length); // <- update nav count
}

async function removeFromCart(gameId) {
    try {
        const userId = localStorage.getItem('userId');
        console.log('Sending delete request with:', { userId, gameId }); // Check the values here

        const response = await fetch('http://localhost:3000/api/cart/item', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId, gameId })
        });

        if (!response.ok) throw new Error(await response.text());
        await loadCart(); // Refresh cart
    } catch (error) {
        console.error('Remove item error:', error);
        alert('Failed to remove item: ' + error.message);
    }
}


async function setupCheckout() {
    document.getElementById('checkoutBtn').addEventListener('click', async () => {
        const btn = document.getElementById('checkoutBtn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';

        try {
            const baseUrl = 'http://localhost:3000';
            const userId = localStorage.getItem('userId');
            const paymentMethod = document.getElementById('paymentMethod').value.trim();
            const totalAmount = parseFloat(document.getElementById('total').textContent.replace('$', ''));

            // Validate payment method
            const validPaymentMethods = ['Credit Card', 'Debit Card', 'PayPal'];
            if (!validPaymentMethods.includes(paymentMethod)) {
                alert('Invalid payment method selected.');
                return;
            }

            console.log('Raw payment method:', paymentMethod);
            console.log('Trimmed payment method:', paymentMethod.trim());
            console.log('Type of payment method:', typeof paymentMethod);

            // 1. Create order
            const orderResponse = await fetch(`${baseUrl}/api/order/place`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userId,totalAmount })
            });

            const orderData = await orderResponse.json();
            if (!orderResponse.ok) {
                throw new Error(orderData.message || 'Order creation failed');
            }

            console.log("ot",orderData)
            // ✅ Step 2: Process payment with trimmed method
            const paymentResponse = await fetch(`${baseUrl}/api/payments`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    userId,
                    orderId: orderData.orderId,
                    method: paymentMethod,  // Already trimmed above
                    amount: totalAmount
                })
            });

            if (!paymentResponse.ok) {
                const error = await paymentResponse.json();
                throw new Error(error.message || 'Payment processing failed');
            }

            // Success
            window.location.href = `order_summary.html?orderId=${orderData.orderId}`;

        } catch (error) {
            console.error('Checkout error:', {
                message: error.message,
                stack: error.stack
            });
            alert(`Checkout failed: ${error.message}\n\nPlease try again.`);
        } finally {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-lock"></i> Proceed to Checkout';
        }
    });
}

function updateTotal(items) {
    const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = subtotal * 0.1; // or 0 if you don’t want tax
    const total = subtotal + tax;

    document.getElementById('subtotal').textContent = `$${subtotal.toFixed(2)}`;
    document.getElementById('tax').textContent = `$${tax.toFixed(2)}`;
    document.getElementById('total').textContent = `$${total.toFixed(2)}`;
}

function updateCartCountDisplay(count) {
    const cartCount = document.getElementById('cart-count');
    if (cartCount) {
        cartCount.textContent = count;
    }
}
