document.addEventListener('DOMContentLoaded', async () => {
    await loadCart();
    setupCheckoutSteps();
    updateCartCount();
});

function setupCheckoutSteps() {
    const reviewSection = document.getElementById('order-review-section');
    const paymentSection = document.getElementById('payment-section');
    const confirmationSection = document.getElementById('confirmation-section');
  
    // Click "Continue to Payment" button
    document.getElementById('btn-to-payment').addEventListener('click', () => {
        reviewSection.classList.remove('active');
        paymentSection.classList.add('active');
        document.getElementById('step-1').classList.remove('active');
        document.getElementById('step-2').classList.add('active');
    });
  
    // Click "Back to Review" button
    document.getElementById('btn-back-to-review').addEventListener('click', () => {
        paymentSection.classList.remove('active');
        reviewSection.classList.add('active');
        document.getElementById('step-2').classList.remove('active');
        document.getElementById('step-1').classList.add('active');
    });
  
    // Click "Complete Order" button
    document.getElementById('btn-complete-order').addEventListener('click', async () => {
        await checkout();
        paymentSection.classList.remove('active');
        confirmationSection.classList.add('active');
        document.getElementById('step-2').classList.remove('active');
        document.getElementById('step-3').classList.add('active');
    });
}

async function loadCart() {
    const userId = localStorage.getItem('userId');
    if (!userId) {
        window.location.href = 'login_registration.html';
        return;
    }
  
    const urlParams = new URLSearchParams(window.location.search);
    const orderId = urlParams.get('orderId');
  
    if (!orderId) {
        alert('Order ID is required');
        return;
    }
  
    try {
        const response = await fetch(`http://localhost:3000/api/orderdetails?orderId=${orderId}`);
        const orderDetails = await response.json();
        renderOrderSummary(orderDetails); // Display the order summary
    } catch (err) {
        console.error(err);
        alert('Failed to load order details');
    }
}

function renderOrderSummary(orderDetails) {
    const container = document.getElementById('order-items');
    const subtotalEl = document.getElementById('order-subtotal');
    const taxEl = document.getElementById('order-tax');
    const totalEl = document.getElementById('order-total');
  
    if (!orderDetails || orderDetails.length === 0) {
        container.innerHTML = '<p>No items in the order.</p>';
        subtotalEl.textContent = '$0.00';
        taxEl.textContent = '$0.00';
        totalEl.textContent = '$0.00';
        return;
    }
  
    // Rendering order items
    container.innerHTML = orderDetails.map(item => `
      <div class="order-item">
        <div>
          <h3>${item.title}</h3>
          <p>Price: $${item.price} × ${item.quantity}</p>
        </div>
        <div>
          <strong>Total: $${(item.price * item.quantity).toFixed(2)}</strong>
        </div>
      </div>
    `).join('');
  
    // Calculate subtotal, tax, and total
    const subtotal = orderDetails.reduce((acc, item) => acc + (parseFloat(item.price) * item.quantity), 0);
    const tax = subtotal * 0.1; // 10% tax
    const total = subtotal + tax;
  
    // Display subtotal, tax, and total
    subtotalEl.textContent = `$${subtotal.toFixed(2)}`;
    taxEl.textContent = `$${tax.toFixed(2)}`;
    totalEl.textContent = `$${total.toFixed(2)}`;
}

async function checkout() {
    const userId = localStorage.getItem('userId');
    const paymentMethod = document.querySelector('input[name="payment-method"]:checked').value;
    const shippingAddress = document.getElementById('shipping-address').value;
    const urlParams = new URLSearchParams(window.location.search);
    const orderId = urlParams.get('orderId');

    try {
        const res = await fetch('http://localhost:3000/api/cart/checkout', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                userId,
                orderId,
                paymentMethod,
                shippingAddress
            })
        });

        if (!res.ok) {
            const errData = await res.json();
            throw new Error(errData.error || 'Checkout failed');
        }

        const confirmation = await res.json();
        console.log('Checkout confirmation:', confirmation); // Confirmation data

        // Show success message
        alert('Your order has been completed successfully!');

        // Redirect to home page (e.g., 'index.html')
        window.location.href = 'home.html'; // Change this URL to your home page if it's different
    } catch (err) {
        alert(err.message);
    }
}


async function updateCartCount() {
    const userId = localStorage.getItem('userId');
    try {
        const res = await fetch(`http://localhost:3000/api/cart/count?userId=${userId}`);
        if (!res.ok) {
            throw new Error('Failed to fetch cart count');
        }
        const { count } = await res.json();
        document.getElementById('cart-count').textContent = count;
    } catch (err) {
        console.error('Cart count update failed:', err);
    }
}
