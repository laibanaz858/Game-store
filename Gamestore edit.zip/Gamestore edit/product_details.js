document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Enhanced fetch with error handling
        const response = await fetch(`http://localhost:3000/api/games`);
        
        console.log('API Response Status:', response.status);
        
        if (!response.ok) {
            throw new Error(`Server returned ${response.status}: ${response.statusText}`);
        }
        
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            throw new Error('Received non-JSON response');
        }
        
        const games = await response.json();
        console.log('Games loaded:', games);
        
        displayGames(games);
        setupFilters(games);
    } catch (error) {
        console.error('Error loading games:', error);
        showError(error);
    }
});

function displayGames(games) {
    const gamesGrid = document.getElementById('gamesGrid');
    
    if (!games || games.length === 0) {
        gamesGrid.innerHTML = '<p class="no-games">No games available at the moment</p>';
        return;
    }
    
    gamesGrid.innerHTML = games.map(game => `
        <div class="game-card" data-platform="${game.platform}" data-genre="${game.genre}">
            <div class="game-image">
                <img src="${game.image_path || 'images/default-game.jpg'}" 
                     alt="${game.title}" 
                     onerror="this.src='images/default-game.jpg'">
                ${game.stock_quantity <= 0 ? '<span class="out-of-stock">Out of Stock</span>' : ''}
            </div>
            <div class="game-info">
                <h3>${game.title}</h3>
                <div class="game-meta">
                    <span class="platform">${game.platform}</span>
                    <span class="genre">${game.genre}</span>
                </div>
                <div class="game-footer">
                    <span class="price">$${game.price}</span>
                    <button onclick="addToCart(${game.game_id})" 
                            ${game.stock_quantity <= 0 ? 'disabled' : ''}>
                        ${game.stock_quantity <= 0 ? 'Out of Stock' : 'Add to Cart'}
                    </button>
                </div>
            </div>
            <a href="product_details.html?id=${game.game_id}" class="view-details">View Details</a>
        </div>
    `).join('');
}

function setupFilters(allGames) {
    const platformFilter = document.getElementById('platformFilter');
    const genreFilter = document.getElementById('genreFilter');
    
    if (!platformFilter || !genreFilter) return;
    
    function applyFilters() {
        const platform = platformFilter.value;
        const genre = genreFilter.value;
        
        const filteredGames = allGames.filter(game => {
            return (platform === 'all' || game.platform === platform) &&
                   (genre === 'all' || game.genre === genre);
        });
        
        displayGames(filteredGames);
    }
    
    platformFilter.addEventListener('change', applyFilters);
    genreFilter.addEventListener('change', applyFilters);
}

function showError(error) {
    const gamesGrid = document.getElementById('gamesGrid');
    if (!gamesGrid) return;
    
    gamesGrid.innerHTML = `
        <div class="error-message">
            <p>Failed to load games. Please try again later.</p>
            ${error.message ? `<p><small>${error.message}</small></p>` : ''}
            <button onclick="location.reload()">Retry</button>
        </div>
    `;
}

/////////////////////
async function addToCart(gameId) {
    const button = event.target;
    const originalText = button.textContent;
    
    try {
        // Show loading state
        button.disabled = true;
        button.textContent = '...';

        const userId = localStorage.getItem('userId');
        if (!userId) {
            window.location.href = 'login_registration.html';
            return;
        }

        const response = await fetch('http://localhost:3000/api/cart/add', {

            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                userId: parseInt(userId),
                gameId: parseInt(gameId)
            })
        });

        const result = await response.json();
        
        if (!response.ok || !result.success) {
            throw new Error(result.message || 'Failed to add to cart');
        }

        // Visual feedback
        button.textContent = '✓ Added!';
        setTimeout(() => {
            button.textContent = originalText;
        }, 2000);

        // Update cart counter
        updateCartCount();

    } catch (error) {
        console.error('Cart Error:', error);
        button.textContent = 'Failed! Try Again';
        setTimeout(() => {
            button.textContent = originalText;
        }, 1500);
        
        alert(`Error: ${error.message}`);
    } finally {
        button.disabled = false;
    }
}
// Add this function to update cart counter
async function updateCartCount() {
    const userId = localStorage.getItem('userId');
    if (!userId) return;

    try {
        const response = await fetch(`/api/cart/count?userId=${userId}`);
        if (response.ok) {
            const data = await response.json();
            const cartCount = document.getElementById('cart-count');
            if (cartCount) {
                cartCount.textContent = data.count || 0;
                cartCount.style.display = 'inline-block';
            }
        }
    } catch (error) {
        console.error('Cart count update failed:', error);
    }
}
async function updateCartCount() {
    const userId = localStorage.getItem('userId');
    if (!userId) return;

    try {
        const response = await fetch(`/api/cart/count?userId=${userId}`);
        if (response.ok) {
            const data = await response.json();
            const cartCountElement = document.getElementById('cart-count');
            if (cartCountElement) {
                cartCountElement.textContent = data.count || 0;
            }
        }
    } catch (error) {
        console.error('Failed to update cart count:', error);
    }
}

async function fetchGames() {
    try {
        console.log('Starting game fetch...');
        const response = await fetch('/api/games', {
            headers: {
                'Accept': 'application/json'
            }
        });

        console.log('Received response:', {
            status: response.status,
            statusText: response.statusText
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Server responded with ${response.status}: ${errorText}`);
        }

        const contentType = response.headers.get('content-type');
        if (!contentType?.includes('application/json')) {
            const body = await response.text();
            console.error('Non-JSON response:', body);
            throw new Error('Received non-JSON response');
        }

        return await response.json();
    } catch (error) {
        console.error('FETCH ERROR:', {
            message: error.message,
            stack: error.stack
        });
        throw error;
    }
}