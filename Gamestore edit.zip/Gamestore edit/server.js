require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const app = express();

// Enhanced CORS configuration
app.use(cors({
    origin: true, // Allow all origins in development
    credentials: true,
    methods: ['GET', 'POST', 'OPTIONS','DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname))); // Serve static files from root

// Database config
const dbPool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'Lb@12345',
    database: process.env.DB_NAME || 'gamestore',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
    
});

// Example usage
dbPool.getConnection().then(() => {
    console.log('✅ Connected to MySQL');
}).catch(err => {
    console.error('❌ MySQL connection failed', err);
});

// ==================== FRONTEND ROUTES ====================
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'home.html')));
app.get('/home', (req, res) => res.sendFile(path.join(__dirname, 'home.html')));
app.get('/login_registration', (req, res) => res.sendFile(path.join(__dirname, 'login_registration.html')));
app.get('/product_details', (req, res) => res.sendFile(path.join(__dirname, 'product_details.html')));
app.get('/cart', (req, res) => res.sendFile(path.join(__dirname, 'cart.html')));
app.get('/order_summary', (req, res) => res.sendFile(path.join(__dirname, 'order_summary.html')));

// ==================== API ENDPOINTS ====================

// Health check
app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        database: dbPool.connected ? 'Connected' : 'Disconnected',
        timestamp: new Date()
    });
});

// Login
// Login
app.post('/api/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Email and password are required'
            });
        }

        const [rows] = await dbPool.execute(
            'SELECT user_id, username, password, role FROM Users WHERE email = ?',
            [email]
        );

        const user = rows[0];

        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Invalid credentials'
            });
        }

        const passwordMatch = await bcrypt.compare(password, user.password);

        if (!passwordMatch) {
            return res.status(401).json({
                success: false,
                message: 'Invalid credentials'
            });
        }

        res.json({
            success: true,
            userId: user.user_id,
            username: user.username,
            role: user.role,
            message: 'Login successful'
        });

    } catch (err) {
        console.error('Login error:', err);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});


// Registration
// Register
app.post('/api/register', async (req, res) => {
    try {
        const { name, email, password } = req.body;

        if (!name || !email || !password) {
            return res.status(400).json({
                success: false,
                message: 'All fields are required'
            });
        }

        if (password.length < 6) {
            return res.status(400).json({
                success: false,
                message: 'Password must be at least 6 characters'
            });
        }

        const [existing] = await dbPool.execute(
            'SELECT email FROM Users WHERE email = ?',
            [email]
        );

        if (existing.length > 0) {
            return res.status(400).json({
                success: false,
                message: 'Email already registered'
            });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const role = 'Customer';

        await dbPool.execute(
            'INSERT INTO Users (username, email, password, role) VALUES (?, ?, ?, ?)',
            [name, email, hashedPassword, role]
        );

        res.status(201).json({
            success: true,
            message: 'User registered successfully'
        });

    } catch (err) {
        console.error('Registration error:', err);
        res.status(500).json({
            success: false,
            message: 'Registration failed'
        });
    }
});

// Games endpoint
app.get('/api/games', async (req, res) => {
    console.log('Attempting to fetch games...');
    try {
        const [rows] = await dbPool.query('SELECT g.* FROM Games g'); // Simplified query for testing
        
        console.log(`Successfully fetched ${rows.length} games`);
        
        res.setHeader('Content-Type', 'application/json');
        res.json(rows);
    } catch (err) {
        console.error('DATABASE ERROR:', err);
        res.status(500).json({ 
            error: 'Failed to fetch games',
            details: err.message,
            stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
        });
    }
});

// Cart endpoints
app.post('/api/cart/add', async (req, res) => {
    try {
        const { userId, gameId } = req.body;
        
        if (!userId || !gameId) {
            return res.status(400).json({ 
                success: false,
                message: 'User ID and Game ID are required' 
            });
        }

        // Check if the game is already in the cart
        const [existingCart] = await dbPool.query('SELECT * FROM Cart WHERE user_id = ? AND game_id = ?', [userId, gameId]);

        if (existingCart.length > 0) {
            // If the game already exists in the cart, update the quantity
            await dbPool.query('UPDATE Cart SET quantity = quantity + 1 WHERE user_id = ? AND game_id = ?', [userId, gameId]);
        } else {
            // Otherwise, insert a new record into the Cart
            await dbPool.query('INSERT INTO Cart (user_id, game_id, quantity) VALUES (?, ?, 1)', [userId, gameId]);
        }

        res.json({ success: true });
    } catch (err) {
        console.error('Cart error:', err);
        res.status(500).json({ 
            success: false,
            message: 'Failed to add to cart' 
        });
    }
});


app.get('/api/cart', async (req, res) => {
    try {
        const userId = req.query.userId;
        if (!userId) return res.status(400).json({ error: 'User ID required' });

        const [rows] = await dbPool.query(`
            SELECT g.*, c.quantity 
            FROM Cart c
            JOIN Games g ON c.game_id = g.game_id
            WHERE c.user_id = ?
        `, [userId]);

        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});


app.delete('/api/cart/item', async (req, res) => {
    try {
        const { userId, gameId } = req.body;
        
        // Deleting the item from the cart
        const [result] = await dbPool.query('DELETE FROM Cart WHERE user_id = ? AND game_id = ?', [userId, gameId]);

        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/orderdetails', async (req, res) => {
    const orderId = req.query.orderId;

    if (!orderId) {
        return res.status(400).json({ error: 'Order ID is required' });
    }

    try {
        const [rows] = await dbPool.query(`
            SELECT od.order_id, od.game_id, od.quantity, od.price, g.title
            FROM OrderDetails od
            JOIN Games g ON od.game_id = g.game_id
            WHERE od.order_id = ?
        `, [orderId]);

        res.json(rows);
    } catch (error) {
        console.error('Error loading order details:', error);
        res.status(500).json({ error: 'Failed to load order details' });
    }
});



// Test endpoint
app.get('/api/test', (req, res) => {
    res.json({ message: 'API test successful', timestamp: new Date() });
});

// Database test endpoint
app.get('/api/test-db', async (req, res) => {
    try {
        const result = await dbPool.request().query('SELECT 1 AS test');
        res.json({ success: true, data: result.recordset });
    } catch (err) {
        res.status(500).json({ 
            success: false, 
            error: err.message,
            config: dbConfig
        });
    }
});

// Wildcard route
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'home.html'));
});

// Error handling
app.use((err, req, res, next) => {
    console.error('Server error:', err);
    res.status(500).json({
        success: false,
        message: 'Internal server error'
    });
});

// Start server
const PORT = process.env.PORT || 3001;
const server = app.listen(PORT, () => {
    console.log(`
    🚀 Server running on http://localhost:${PORT}
    📚 Available Endpoints:
    - POST   /api/login
    - POST   /api/register
    - GET    /api/games
    - POST   /api/cart/add
    - GET    /api/cart
    - DELETE /api/cart/item
    - GET    /api/health
    `);
});

server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
        console.error('⚠  Port ${PORT} is already in use');
        console.log('Try these solutions:');
        console.log('1. Find process: netstat -ano | findstr :${PORT}');
        console.log('2. Kill process: taskkill /PID <PID> /F');
        console.log('3. Or change port in server.js (currently ${PORT})');
    } else {
        console.error('Server startup error:', err);
    }
});

process.on('SIGINT', () => {
    console.log('\nShutting down server...');
    dbPool?.close();
    server.close(() => {
        console.log('Server terminated');
        process.exit(0);
    });
});

/////////////////////////////////////////////////////
// Place Order & Process Payment
// Order Placement Route
app.post('/api/order/place', async (req, res) => {
    const connection = await dbPool.getConnection();
    
    try {
        await connection.beginTransaction();
        
        const { userId, totalAmount } = req.body;

        // Validate input
        if (!userId || isNaN(totalAmount)) {
            await connection.rollback();
            return res.status(400).json({ 
                success: false,
                message: 'Valid userId and totalAmount are required'
            });
        }

        console.log(`Placing order for userId: ${userId}, totalAmount: ${totalAmount}`);

        // 1. Verify user exists
        const [userCheck] = await connection.query('SELECT 1 FROM Users WHERE user_id = ?', [userId]);
        if (userCheck.length === 0) {
            await connection.rollback();
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        // 2. Create order
        // 1. Create the order in the database
const [orderResult] = await connection.query(`
    INSERT INTO Orders (user_id, total_amount)
    VALUES (?, ?)
`, [userId, totalAmount]);

// 2. MySQL auto-generates the orderId (auto-increment)
const orderId = orderResult.insertId; // ← THIS IS THE GENERATED ORDER ID

// 3. Send it back to the frontend
res.json({ 
    success: true, 
    message: 'Order placed successfully',
    orderId // ← RETURNED TO FRONTEND
});
        
        //console.log(`Order created with orderId: ${orderId}`);

        // 3. Get cart items
        const [cartItems] = await connection.query(`
            SELECT c.game_id, c.quantity, g.price
            FROM Cart c
            JOIN Games g ON c.game_id = g.game_id
            WHERE c.user_id = ?
        `, [userId]);

        console.log(`Fetched ${cartItems.length} items from cart`);

        // 4. Add order items
        for (const item of cartItems) {
            console.log(`Adding item to order: gameId: ${item.game_id}, quantity: ${item.quantity}, price: ${item.price}`);
            await connection.query(`
                INSERT INTO OrderDetails (order_id, game_id, quantity, price)
                VALUES (?, ?, ?, ?)
            `, [orderId, item.game_id, item.quantity, item.price]);
        }

        console.log('All order items added successfully');

        // 5. Clear cart
        await connection.query('DELETE FROM Cart WHERE user_id = ?', [userId]);
        console.log('Cart cleared successfully');

        // Commit the transaction
        await connection.commit();
        res.json({ 
            success: true, 
            message: 'Order placed successfully' ,
            orderId
        });
    } catch (err) {
        console.error('Order creation failed:', err);
        await connection.rollback();
        res.status(500).json({ 
            success: false, 
            message: 'Order creation failed', 
            error: err.message 
        });
    } finally {
        connection.release(); // Always release the connection back to the pool
    }
});


// Payment Route
app.post('/api/payments', async (req, res) => {
    const connection = await dbPool.getConnection(); // Getting a connection from the pool

    try {
        await connection.beginTransaction(); // Begin a transaction

        const { userId, orderId, method, amount } = req.body;

        console.log('Received payment data:', req.body);

        // 1. Validate required fields
        if (!method || typeof method !== 'string') {
            await connection.rollback(); // Rollback the transaction in case of validation failure
            return res.status(400).json({
                success: false,
                message: 'Payment method is required'
            });
        }

        console.log('Received payment method:', method);

        // Payment method validation
        const validMethods = ['Credit Card', 'Debit Card', 'PayPal'];  // Example valid methods

        // Trim and log the payment method to ensure no whitespaces are causing the issue
        const trimmedMethod = method.trim();
        console.log('Trimmed payment method:', trimmedMethod);  // Log trimmed method

        // Check if the trimmed method is valid
        if (!validMethods.includes(trimmedMethod)) {
            console.log('Invalid payment method:', trimmedMethod);  // Log invalid method if any
            return res.status(400).json({ error: 'Invalid payment method' });
        }

        // 2. Insert payment into the database
        const [paymentResult] = await connection.query(`
            INSERT INTO Payments (
                order_id,
                payment_method,
                payment_status,
                amount,
                payment_date
            )
            VALUES (?, ?, 'Success', ?, NOW())
        `, [orderId, trimmedMethod, amount]);

        const paymentId = paymentResult.insertId;  // Get the inserted payment ID

        console.log(`Payment processed successfully with payment_id: ${paymentId}`);

        // Commit the transaction
        await connection.commit();

        res.json({
            success: true,
            paymentId: paymentId // Return the inserted payment ID
        });

    } catch (error) {
        await connection.rollback(); // Rollback in case of an error
        console.error('Payment error:', error);
        res.status(500).json({
            success: false,
            message: 'Payment processing failed',
            error: error.message
        });
    } finally {
        connection.release(); // Always release the connection back to the pool
    }
});


app.post('/api/cart/checkout', async (req, res) => {
    const { userId } = req.body;

    if (!userId) {
        return res.status(400).json({ error: 'User ID is required' });
    }

    try {
        // Fetch the order details directly from the OrderDetails table using orderId
        const { orderId } = req.body;
        
        if (!orderId) {
            return res.status(400).json({ error: 'Order ID is required' });
        }

        // Fetch order details based on orderId
        const [orderDetails] = await dbPool.query(`
            SELECT od.game_id, od.quantity, od.price, g.title
            FROM OrderDetails od
            JOIN Games g ON od.game_id = g.game_id
            WHERE od.order_id = ?
        `, [orderId]);

        if (orderDetails.length === 0) {
            return res.status(400).json({ error: 'No details found for this order' });
        }

        // Calculate the total amount for the order based on order details
        let totalAmount = 0;
        orderDetails.forEach(item => {
            totalAmount += item.price * item.quantity;
        });

        // Insert a new order into Orders table (if needed)
        // For this scenario, we assume the order is already created and we just confirm it.

        // You can add order status updates or other processing logic if necessary.

        res.json({
            orderId,
            orderDetails,
            totalAmount,
            message: 'Order confirmed successfully'
        });
    } catch (error) {
        console.error('Error during checkout:', error);
        res.status(500).json({ error: 'Failed to fetch order details' });
    }
});


app.get('/api/cart/count', async (req, res) => {
    const { userId } = req.query;

    if (!userId) {
        return res.status(400).json({ error: 'User ID is required' });
    }

    try {
        const [cartItems] = await dbPool.query(`
            SELECT COUNT(*) as count
            FROM Cart
            WHERE user_id = ?
        `, [userId]);

        res.json(cartItems[0]);
    } catch (error) {
        console.error('Error fetching cart count:', error);
        res.status(500).json({ error: 'Failed to fetch cart count' });
    }
});

